#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Рендер INSTRUKCIYA.md → аккуратный PDF с кириллицей и блоками команд."""
import re
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer,
    Table, TableStyle, HRFlowable, KeepTogether, Preformatted
)
from reportlab.lib.styles import ParagraphStyle

DJ = "/usr/share/fonts/truetype/dejavu/"
pdfmetrics.registerFont(TTFont("DJSans",      DJ + "DejaVuSans.ttf"))
pdfmetrics.registerFont(TTFont("DJSans-Bold", DJ + "DejaVuSans-Bold.ttf"))
pdfmetrics.registerFont(TTFont("DJSans-Obl",  DJ + "DejaVuSans-Oblique.ttf"))
pdfmetrics.registerFont(TTFont("DJMono",      DJ + "DejaVuSansMono.ttf"))
pdfmetrics.registerFont(TTFont("DJMono-Bold", DJ + "DejaVuSansMono-Bold.ttf"))

# Палитра (Nexus light, акцент — Hydra Teal)
INK    = colors.HexColor("#28251D")
MUTED  = colors.HexColor("#7A7974")
TEAL   = colors.HexColor("#01696F")
TEALD  = colors.HexColor("#0C4E54")
BORDER = colors.HexColor("#D4D1CA")
CODEBG = colors.HexColor("#F1EFEA")
WARNBG = colors.HexColor("#FBF2E9")
WARN   = colors.HexColor("#964219")

SRC = "/home/user/workspace/bot/INSTRUKCIYA.md"
OUT = "/home/user/workspace/Instrukciya-svodka-bot.pdf"

styles = {
    "h1": ParagraphStyle("h1", fontName="DJSans-Bold", fontSize=19, leading=24,
                         textColor=TEALD, spaceBefore=4, spaceAfter=10),
    "h2": ParagraphStyle("h2", fontName="DJSans-Bold", fontSize=14.5, leading=19,
                         textColor=TEAL, spaceBefore=16, spaceAfter=6),
    "h3": ParagraphStyle("h3", fontName="DJSans-Bold", fontSize=11.5, leading=15,
                         textColor=INK, spaceBefore=10, spaceAfter=4),
    "body": ParagraphStyle("body", fontName="DJSans", fontSize=10, leading=15,
                           textColor=INK, spaceAfter=6, alignment=TA_LEFT),
    "li": ParagraphStyle("li", fontName="DJSans", fontSize=10, leading=15,
                         textColor=INK, leftIndent=14, spaceAfter=3,
                         bulletIndent=2, bulletFontName="DJSans", bulletFontSize=10),
    "li2": ParagraphStyle("li2", fontName="DJSans", fontSize=10, leading=15,
                          textColor=INK, leftIndent=30, spaceAfter=2,
                          bulletIndent=18),
    "note": ParagraphStyle("note", fontName="DJSans", fontSize=9.5, leading=14,
                           textColor=WARN, leftIndent=8, rightIndent=8,
                           spaceBefore=2, spaceAfter=2),
    "cell": ParagraphStyle("cell", fontName="DJSans", fontSize=9.5, leading=13,
                           textColor=INK),
    "cellm": ParagraphStyle("cellm", fontName="DJMono", fontSize=9, leading=13,
                            textColor=TEALD),
}
code_style = ParagraphStyle("code", fontName="DJMono", fontSize=8.6, leading=12.5,
                            textColor=INK)


def inline(text):
    """Markdown inline → reportlab markup. `code`, **bold**, ссылки как есть."""
    # экранируем XML
    text = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    # `code`
    text = re.sub(r"`([^`]+)`",
                  r'<font face="DJMono" size="9" color="#0C4E54">\1</font>', text)
    # **bold**
    text = re.sub(r"\*\*([^*]+)\*\*", r'<font face="DJSans-Bold">\1</font>', text)
    return text


def parse_md(md):
    """Парсим markdown в список flowables."""
    flow = []
    lines = md.split("\n")
    i = 0
    n = len(lines)
    while i < n:
        line = lines[i]

        # --- горизонтальная линия ---
        if line.strip() == "---":
            flow.append(Spacer(1, 4))
            flow.append(HRFlowable(width="100%", thickness=0.6, color=BORDER,
                                   spaceBefore=2, spaceAfter=8))
            i += 1
            continue

        # --- кодовый блок ---
        if line.strip().startswith("```"):
            i += 1
            buf = []
            while i < n and not lines[i].strip().startswith("```"):
                buf.append(lines[i])
                i += 1
            i += 1  # закрывающий ```
            code = "\n".join(buf)
            tbl = Table([[Preformatted(code, code_style)]], colWidths=[165 * mm])
            tbl.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, -1), CODEBG),
                ("BOX", (0, 0), (-1, -1), 0.5, BORDER),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                ("TOPPADDING", (0, 0), (-1, -1), 6),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ]))
            flow.append(Spacer(1, 2))
            flow.append(tbl)
            flow.append(Spacer(1, 6))
            continue

        # --- таблица markdown ---
        if line.strip().startswith("|") and i + 1 < n and re.match(r"^\s*\|[\s:|-]+\|\s*$", lines[i + 1]):
            header = [c.strip() for c in line.strip().strip("|").split("|")]
            i += 2
            rows = []
            while i < n and lines[i].strip().startswith("|"):
                rows.append([c.strip() for c in lines[i].strip().strip("|").split("|")])
                i += 1
            data = [[Paragraph(inline(c), styles["cell"]) for c in header]]
            for r in rows:
                data.append([Paragraph(inline(c), styles["cell"]) for c in r])
            tbl = Table(data, colWidths=[55 * mm, 110 * mm])
            tbl.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), TEAL),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("FONTNAME", (0, 0), (-1, 0), "DJSans-Bold"),
                ("FONTSIZE", (0, 0), (-1, 0), 9.5),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F7F6F2")]),
                ("GRID", (0, 0), (-1, -1), 0.4, BORDER),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("LEFTPADDING", (0, 0), (-1, -1), 6),
                ("RIGHTPADDING", (0, 0), (-1, -1), 6),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ]))
            flow.append(Spacer(1, 2))
            flow.append(tbl)
            flow.append(Spacer(1, 8))
            continue

        # --- цитата / предупреждение ---
        if line.strip().startswith(">"):
            buf = []
            while i < n and lines[i].strip().startswith(">"):
                buf.append(lines[i].strip().lstrip(">").strip())
                i += 1
            txt = " ".join(buf)
            para = Paragraph(inline(txt), styles["note"])
            tbl = Table([[para]], colWidths=[165 * mm])
            tbl.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, -1), WARNBG),
                ("LINEBEFORE", (0, 0), (0, -1), 2.5, WARN),
                ("LEFTPADDING", (0, 0), (-1, -1), 10),
                ("RIGHTPADDING", (0, 0), (-1, -1), 10),
                ("TOPPADDING", (0, 0), (-1, -1), 7),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
            ]))
            flow.append(Spacer(1, 2))
            flow.append(tbl)
            flow.append(Spacer(1, 6))
            continue

        # --- заголовки ---
        if line.startswith("### "):
            flow.append(Paragraph(inline(line[4:]), styles["h3"]))
            i += 1
            continue
        if line.startswith("## "):
            flow.append(Paragraph(inline(line[3:]), styles["h2"]))
            i += 1
            continue
        if line.startswith("# "):
            flow.append(Paragraph(inline(line[2:]), styles["h1"]))
            i += 1
            continue

        # --- нумерованный список ---
        m = re.match(r"^(\s*)(\d+)\.\s+(.*)$", line)
        if m:
            indent = len(m.group(1))
            st = styles["li2"] if indent >= 2 else styles["li"]
            flow.append(Paragraph(inline(m.group(3)), st, bulletText=m.group(2) + "."))
            i += 1
            continue

        # --- маркированный список ---
        m = re.match(r"^(\s*)[-*]\s+(.*)$", line)
        if m:
            indent = len(m.group(1))
            st = styles["li2"] if indent >= 2 else styles["li"]
            flow.append(Paragraph(inline(m.group(2)), st, bulletText="•"))
            i += 1
            continue

        # --- пустая строка ---
        if not line.strip():
            i += 1
            continue

        # --- обычный абзац (склеиваем многострочные) ---
        buf = [line]
        i += 1
        while i < n and lines[i].strip() and not re.match(
                r"^(#|>|\||```|\s*[-*]\s|\s*\d+\.\s|---)", lines[i]):
            buf.append(lines[i])
            i += 1
        flow.append(Paragraph(inline(" ".join(buf)), styles["body"]))

    return flow


def footer(canvas, doc):
    canvas.saveState()
    canvas.setFont("DJSans", 8)
    canvas.setFillColor(MUTED)
    canvas.drawString(20 * mm, 12 * mm, "Бот сводок ЕДДС — инструкция по настройке")
    canvas.drawRightString(190 * mm, 12 * mm, "Стр. %d" % doc.page)
    canvas.setStrokeColor(BORDER)
    canvas.setLineWidth(0.4)
    canvas.line(20 * mm, 15 * mm, 190 * mm, 15 * mm)
    canvas.restoreState()


def main():
    md = open(SRC, encoding="utf-8").read()
    doc = BaseDocTemplate(
        OUT, pagesize=A4,
        leftMargin=20 * mm, rightMargin=20 * mm,
        topMargin=18 * mm, bottomMargin=20 * mm,
        title="Бот сводок ЕДДС — инструкция по настройке",
        author="Perplexity Computer",
    )
    frame = Frame(doc.leftMargin, doc.bottomMargin,
                  doc.width, doc.height, id="main")
    doc.addPageTemplates([PageTemplate(id="main", frames=[frame], onPage=footer)])
    doc.build(parse_md(md))
    print("PDF saved:", OUT)


if __name__ == "__main__":
    main()
